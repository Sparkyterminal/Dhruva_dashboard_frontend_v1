import React from "react";

const DepartmentsTable = () => {
  return <div>DepartmentsTable</div>;
};

export default DepartmentsTable;
