import React from "react";

const EditVenue = () => {
  return <div>EditVenue</div>;
};

export default EditVenue;
