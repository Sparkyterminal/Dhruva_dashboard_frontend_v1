import React from "react";

const EditSubEvent = () => {
  return <div>EditSubEvent</div>;
};

export default EditSubEvent;
