<<<<<<< HEAD
import React from "react";

const EditSubEvent = () => {
  return <div>EditSubEvent</div>;
};

export default EditSubEvent;
=======
import React from "react";

const EditSubEvent = () => {
  return <div>EditSubEvent</div>;
};

export default EditSubEvent;
>>>>>>> b102b10a05c3c3d535861fb6f47bfb8852d511c4
