import React from "react";

const AddSubVenue = () => {
  return <div>AddSubVenue</div>;
};

export default AddSubVenue;
