import React from "react";

const EditEvents = () => {
  return <div>EditEvents</div>;
};

export default EditEvents;
