<<<<<<< HEAD
import React from "react";

const EditEvents = () => {
  return <div>EditEvents</div>;
};

export default EditEvents;
=======
import React from "react";

const EditEvents = () => {
  return <div>EditEvents</div>;
};

export default EditEvents;
>>>>>>> b102b10a05c3c3d535861fb6f47bfb8852d511c4
