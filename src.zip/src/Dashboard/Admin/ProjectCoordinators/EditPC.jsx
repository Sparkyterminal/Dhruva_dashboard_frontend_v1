import React from "react";

const EditPC = () => {
  return <div>EditPC</div>;
};

export default EditPC;
