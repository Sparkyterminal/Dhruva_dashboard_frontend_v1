import React from "react";

const EditMeetings = () => {
  return <div>EditMeetings</div>;
};

export default EditMeetings;
