import React from "react";

const AddMeetings = () => {
  return <div>AddMeetings</div>;
};

export default AddMeetings;
