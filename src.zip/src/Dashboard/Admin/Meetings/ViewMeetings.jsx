import React from "react";

const ViewMeetings = () => {
  return <div>ViewMeetings</div>;
};

export default ViewMeetings;
